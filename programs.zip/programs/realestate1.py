#Write a Python program to read realestate.csv and display all the UNIQUE cities and the count of unique cities.
import csv
citylist = []
#citylist = ()
with open("realestate.csv","r") as fobj:
    reader= csv.reader(fobj)
    # processing
    for line in reader:
        city = line[1]
        citylist.append(city)
        # display
    for city in set(citylist):
        print(city)
    print()
    print("No. of cities :", len(set(citylist)))

# using set
import csv
cityset = set()

with open("realestate.csv","r") as fobj:
    header = fobj.readline()
    reader= csv.reader(fobj)
    # processing
    for line in reader:
        city = line[1]
        cityset.add(city)
    for city in cityset:
        print(city)
    print()
    print("No. of cities :", len(cityset))
    
# using dictionary
import csv
citydict = dict()

with open("realestate.csv","r") as fobj:
    header = fobj.readline()
    reader= csv.reader(fobj)
    # processing
    for line in reader:
        city = line[1]
        citydict[city] = 1
    for city in citydict:
        print(city)
    print()
    print("No. of cities :", len(citydict.keys()))    