
book = {"chap1":10 ,"chap2":20 ,"chap3":30 ,"chap1":1000}
print(book)
# display keys
print(book.keys())
# display values
print(book.values())
# display item
print(book.items())
# display one value
print(book["chap1"])  #1000
# add new key:value pair
book["chap4"] = 40
book["chap5"] = 50
print(book)

print(book["chap2"])   #20
#print(book["chap8"])   #

print(book.get("chap8"))  # if key is not existing... will return None
print(book.get("chap1"))  # if existing... then display the value

if "chap8" in book:
    print(book["chap8"])
else:
    print("key doesn't exist")

book.pop("chap1")  # If key is removed ... value will also be deleted
print("After pop :", book)

book.popitem()
print("After popitem() :", book)
book.popitem()
print("After popitem() :", book)

# updating dictionary
newbook = {"chap11":110 ,"chap3":30000}
book.update(newbook)  # all the items of newbook will be updated to book
print(book)





# dictionary
book = {"chap1":10 ,"chap2":20 ,"chap3":30 ,"chap1":1000}


# display keys
for key in book.keys():
    print(key)


# display keys
for key in book:
    print(key)

# display values
for value in book.values():
    print(value)


#display one key,onevalue
for key,value in book.items():
    print(key,value)






















      
