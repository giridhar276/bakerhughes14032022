
# variable length args

def display(*args):
    for val in args:
        print(val)

display(10,20,30,40,50,60,"unix")




def displayItems(**kargs):
    #logic
    for key,value in kargs.items():
        if isinstance(value,list):
            print('Invalid input')
        else:
            print(kargs)
    

displayItems(chap1 = 10 , chap2 = 20 ,chap3 =30)