


class Employee:
    def getEmployee(self,name):
        self.name = name
        
    def displayEmployee(self):
        print(self.name)
        
     
emp1 = Employee()
emp1.getEmployee("Ram")
emp1.displayEmployee()


emp2 = Employee()
emp2.getEmployee("Rita")
emp2.displayEmployee()


