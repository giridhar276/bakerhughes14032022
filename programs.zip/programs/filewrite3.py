
# traditional way  
# legacy way
fobj = open("languages.txt","w")
# operation
fobj.write("python programming\n")
fobj.write("spark\n")
fobj.close()


# context manager
#pythonic way
# Advantage: file gets closed automatically when we move out of indentation
with open("languages.txt","w") as fobj:
    fobj.write("unix programming\n")
    fobj.write("scala\n")
    


    
    

