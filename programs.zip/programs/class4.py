import csv
from openpyxl import Workbook
import os
import time



class CSVToExcel:
    def __init__(self,file):
        self.file = file
    def process(self):
        wb = Workbook()  
        # grab the active worksheet
        ws = wb.active
        if os.path.isfile(self.file) and os.path.getsize(self.file) > 0 and self.file.endswith(".csv"):
            with open(self.file) as self.fobj:
                self.reader = csv.reader(self.fobj)       
                for line in self.reader:
                    ws.append(line)
        
                excelfile = time.strftime("%d_%b_%Y.xlsx")
                if os.path.exists(excelfile):
                    file = excelfile.split(".")
                    file[0] = file[0] + "_bak"
                    excelfile = ".".join(file)
                    wb.save(excelfile)
                else:
                    wb.save(excelfile)


e = CSVToExcel("realestate.csv")
e.process()
