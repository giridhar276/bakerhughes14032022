
# all the methods will be imported
import math
print(math.floor(34.3))
print(math.tan(2))



#importing with aliasname
import math as m
print(m.ceil(2))
print(m.cos(2))


#importing required methods only
# . is not required here
from math import floor,log,factorial  # import these methods only
print(floor(23.3))
print(log(3))

