

import csv
citylist = []
#citylist = ()
try:
    filename = input("Enter any filename :")
    with open(filename,"r") as fobj:
        reader= csv.reader(fobj)
        for line in reader:
            city = line[1]
            citylist.append(city)
            
    output = "hello" + str(9)
    print(output)
    
    alist = [10,20]
    print(alist[100])
    
except Exception as error:
    print(error)    
