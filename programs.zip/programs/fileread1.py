#method1
#fobj acts as file reference or file pointer or file variable or file object
with open("languages.txt","r") as fobj:
    for line in fobj:
        # remove white spaces if any
        line = line.strip()
        print(line)
      
#method2
# generally good to read config files which are in KBs or MBs
# we cannot process anything
# fobj.read()  - display the file content all at once
with open("languages.txt","r") as fobj:
    print(fobj.read())
    
# display first 30 characters
with open("languages.txt","r") as fobj:
    print(fobj.read(30))      
    
    
#method3  
# fobj.readlines() 
# display everything in list format
with open("languages.txt","r") as fobj:
    #print(fobj.readlines())
    output = list(map(lambda x: "language," + x, fobj.readlines()))
    print(output)


with open("languages.txt","r") as fobj:
    for line in fobj.readlines():
        print(line.strip())