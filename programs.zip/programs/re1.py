
import re

with open("info.txt") as fobj:
    for line in fobj:
        line = line.strip()
        if re.search("pyt{1}hon",line):
            print(line)
            
    
    
    

import re

with open("info.txt") as fobj:
    for line in fobj:
        line = line.strip()
        line = re.sub("pyt*hon","ruby",line)
        print(line)
            