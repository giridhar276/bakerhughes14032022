import csv
from openpyxl import Workbook
import os
import time
try:    
    wb = Workbook()  
    # grab the active worksheet
    ws = wb.active
    filename = "realestate.csv"
    if os.path.isfile(filename) and os.path.getsize(filename) > 0 and filename.endswith(".csv"):
        with open(filename) as fobj:
            reader = csv.reader(fobj)
            for line in reader:
                # Rows can also be appended
                ws.append(line)
        
            # Save the file
            excelfile = time.strftime("%d_%b_%Y.xlsx")
            if os.path.exists(excelfile):
                file = excelfile.split(".")
                file[0] = file[0] + "_bak"
                excelfile = ".".join(file)
                wb.save(excelfile)
            else:
                wb.save(excelfile)
    else:
        print("file doesn't exist")
except Exception as err:
    print(err)