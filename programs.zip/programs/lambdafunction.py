
def display(a,b):
    c = a + b
    return c

# calling function
tot = display(10,20)
print(tot)



#lambda function - inline function,nameless function
#when the calling function in invoked ... expression gets replaced in function directly


#function= lambda variables :expression
display  = lambda x,y: x + y
# calling function
print(display(10,20))

#task1
alist = [10,20,30,40]
#output [15,25,35,45]

display=lambda x:x+5
alist=[10,20,30,40]
lst=[]
for i in alist:
    lst.append(display(i))
print(lst)


alist =[10,20,30,40]
print([(lambda x: x+5)(x) for x in alist])

blist = []
for val in alist:
    blist.append(val + 5)
print(blist)

alist = [10,20,30,40]
def increment(x):
    return x + 5
print(list(map(increment,alist)))




alist = [10,20,30,40]
increment = lambda x: x + 5
print(list(map(increment,alist)))



alist = [10,20,30,40]
print(list(map(lambda x: x + 5,alist)))



output= ["  unix  ","java ","oracle   "]
#["unix","java","oracle"]
print(list(map(lambda x: x.strip(),output)))





#INput
numbers = [45,34,54,3,6,2,56,5,98]
#output
evens = [34,54,6,2,56,98]
print(list(filter(lambda x: x%2==0,numbers)))
print(list(filter(lambda x: x%2,numbers)))




output = lambda x : "even" if ( x%2 == 0) else "False"
print(output(100))





getsum = lambda *values : sum(values)
print(getsum(10,20,0,30,40,50,60,60,60))



    
name = "python"
name.isalnum()
    
    
    
    
    
alist = [10,20,30,40]
def increment(x):
    return x+5
print(list(map(increment,alist))) 
    

'12'.isdigit()



def out():
    #line1






