
# constructor
# constructor will be invoked automatically when the object is created

class Employee:
    # constructor
    def __init__(self,name,eid,loc):
        self.name = name
        self.eid = eid
        self.loc   = loc
        
    def displayEmployee(self):
        print(self.name)
        print(self.eid)
        print(self.loc)
        
emp1 = Employee('Ram',11,'Mumbai')
emp1.displayEmployee()


emp2 = Employee("Rita",12,'Hyderabad')
emp2.displayEmployee()
