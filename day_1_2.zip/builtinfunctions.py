#print()
print(10,20,30)
#range(start,stop,step)
print(list(range(1,10)))
print(list(range(2,10,2)))

#input()
#name = input()
#print("Your name is :", name)
name = input("Enter your name :")
print("Your name is :", name)

alist = [10,45,23,56,43]
print(max(alist))
print(min(alist))
print(sum(alist))



print(type(alist))
print(isinstance(alist,list))  #True
print(isinstance(alist,tuple))
print(isinstance(alist,dict))
print(isinstance(alist,int))


print(chr(97))
print(ord('a'))