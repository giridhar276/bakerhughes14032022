

fixed = "192.168.0."

for val in range(1,11):
    ip = fixed + str(val)
    print(ip)
    
    
    
    
    
# 2nd
fixed= "192.168." 
series = input("Enter the value:")
for val in range(int(series)):
    subip = fixed + str(val)
    for val in range(1,11):
        ip = subip + "." + str(val)
        print(ip)